// PPOINNT shared shell — phone frame, tokens, icons, primitives
// All screens render into <Phone> which gives the dark-mode device chrome.

const PP = {
  bg: '#0A0B0D',
  surface: '#121418',
  card: '#16191F',
  cardHi: '#1C2026',
  line: 'rgba(255,255,255,0.06)',
  lineStrong: 'rgba(255,255,255,0.1)',
  text: '#FFFFFF',
  text2: 'rgba(255,255,255,0.62)',
  text3: 'rgba(255,255,255,0.4)',
  text4: 'rgba(255,255,255,0.24)',
  yellow: '#FFC72C',
  yellowDeep: '#E5A800',
  yellowSoft: 'rgba(255,199,44,0.12)',
  yellowGlow: 'rgba(255,199,44,0.35)',
  blue: '#2E6BFF',
  blueSoft: 'rgba(46,107,255,0.14)',
  green: '#23C57A',
  greenSoft: 'rgba(35,197,122,0.14)',
  red: '#E5484D',
  redSoft: 'rgba(229,72,77,0.14)',
  amber: '#F59E0B',
  font: '"Manrope", -apple-system, BlinkMacSystemFont, system-ui, sans-serif',
  mono: '"JetBrains Mono", "SF Mono", ui-monospace, monospace',
};

// ─── Phone frame ───────────────────────────────────────────────
function Phone({ children, w = 380, h = 780, time = '9:41', dark = true, statusDark = false, hideHomeBar = false, style }) {
  return (
    <div style={{
      width: w, height: h, borderRadius: 44,
      background: dark ? PP.bg : '#fff',
      border: `1px solid ${dark ? PP.line : 'rgba(0,0,0,0.08)'}`,
      boxShadow: '0 30px 60px rgba(0,0,0,0.35), 0 0 0 1px rgba(255,255,255,0.04)',
      position: 'relative', overflow: 'hidden',
      fontFamily: PP.font, color: dark ? PP.text : '#0A0B0D',
      WebkitFontSmoothing: 'antialiased', boxSizing: 'border-box',
      ...style,
    }}>
      <StatusBar time={time} dark={statusDark} />
      <div style={{ position: 'absolute', inset: 0, paddingTop: 0, display: 'flex', flexDirection: 'column' }}>
        {children}
      </div>
      {!hideHomeBar && (
        <div style={{
          position: 'absolute', bottom: 6, left: 0, right: 0, height: 22,
          display: 'flex', justifyContent: 'center', alignItems: 'flex-end',
          pointerEvents: 'none', zIndex: 100,
        }}>
          <div style={{ width: 120, height: 4, borderRadius: 100, background: 'rgba(255,255,255,0.5)' }}/>
        </div>
      )}
    </div>
  );
}

function StatusBar({ time = '9:41', dark = false }) {
  const c = dark ? '#0A0B0D' : '#FFF';
  return (
    <div style={{
      position: 'absolute', top: 0, left: 0, right: 0, height: 44, zIndex: 50,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '14px 28px 0', pointerEvents: 'none',
    }}>
      <div style={{ fontSize: 14, fontWeight: 700, letterSpacing: 0.2, color: c, fontFamily: PP.font }}>{time}</div>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center', color: c }}>
        <svg width="16" height="11" viewBox="0 0 16 11" fill={c}><rect x="0" y="7" width="3" height="4" rx=".6"/><rect x="4.3" y="4.5" width="3" height="6.5" rx=".6"/><rect x="8.6" y="2" width="3" height="9" rx=".6"/><rect x="12.9" y="0" width="3" height="11" rx=".6"/></svg>
        <svg width="14" height="10" viewBox="0 0 14 10" fill={c}><path d="M7 2.4c1.9 0 3.6.7 4.9 2l.9-.9C11.2 2 9.2 1.1 7 1.1S2.8 2 1.2 3.5l.9.9C3.4 3.1 5.1 2.4 7 2.4z"/><path d="M7 5.5c1 0 2 .4 2.7 1l.9-.9C9.5 4.7 8.3 4.2 7 4.2s-2.5.5-3.6 1.4l.9.9c.7-.6 1.7-1 2.7-1z"/><circle cx="7" cy="8.4" r="1.2"/></svg>
        <svg width="22" height="11" viewBox="0 0 22 11"><rect x="0.5" y="0.5" width="19" height="10" rx="3" stroke={c} strokeOpacity=".5" fill="none"/><rect x="2" y="2" width="14" height="7" rx="1.5" fill={c}/><path d="M20.5 3.5v4c.7-.2 1.2-.9 1.2-2s-.5-1.8-1.2-2z" fill={c} opacity=".5"/></svg>
      </div>
    </div>
  );
}

// ─── Icons ─────────────────────────────────────────────────────
const I = {
  pin: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><path d="M12 22s-7-7.5-7-13a7 7 0 1 1 14 0c0 5.5-7 13-7 13z" stroke="currentColor" strokeWidth="1.8"/><circle cx="12" cy="9" r="2.5" stroke="currentColor" strokeWidth="1.8"/></svg>,
  pinFill: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" {...p}><path d="M12 22s-7-7.5-7-13a7 7 0 1 1 14 0c0 5.5-7 13-7 13z" fill="currentColor"/><circle cx="12" cy="9" r="2.5" fill="#0A0B0D"/></svg>,
  search: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.8"/><path d="M20 20l-3.5-3.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
  menu: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" {...p}><path d="M4 7h16M4 12h16M4 17h10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" fill="none"/></svg>,
  bell: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2H4.5L6 16z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/><path d="M10 21a2 2 0 0 0 4 0" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
  arrow: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  back: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><path d="M19 12H5M11 18l-6-6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  close: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>,
  plus: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>,
  share: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><circle cx="6" cy="12" r="2.5" stroke="currentColor" strokeWidth="1.8"/><circle cx="18" cy="6" r="2.5" stroke="currentColor" strokeWidth="1.8"/><circle cx="18" cy="18" r="2.5" stroke="currentColor" strokeWidth="1.8"/><path d="M8.5 11l7-4M8.5 13l7 4" stroke="currentColor" strokeWidth="1.6"/></svg>,
  scan: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><path d="M4 8V5a1 1 0 0 1 1-1h3M20 8V5a1 1 0 0 0-1-1h-3M4 16v3a1 1 0 0 0 1 1h3M20 16v3a1 1 0 0 1-1 1h-3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/><path d="M7 12h10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
  nav: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><path d="M3 11L21 4l-7 17-2-7-9-3z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/></svg>,
  home: (p={}) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" {...p}><path d="M4 11l8-7 8 7v9a1 1 0 0 1-1 1h-4v-6h-6v6H5a1 1 0 0 1-1-1v-9z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/></svg>,
  map: (p={}) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" {...p}><path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/><path d="M9 4v14M15 6v14" stroke="currentColor" strokeWidth="1.8"/></svg>,
  bookmark: (p={}) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" {...p}><path d="M6 4h12v17l-6-4-6 4V4z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/></svg>,
  activity: (p={}) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" {...p}><path d="M3 12h4l3-8 4 16 3-8h4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  user: (p={}) => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" {...p}><circle cx="12" cy="8" r="4" stroke="currentColor" strokeWidth="1.8"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
  check: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><path d="M5 12.5l5 5 9-11" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  chevR: (p={}) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" {...p}><path d="M9 6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  chevD: (p={}) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" {...p}><path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  mic: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><rect x="9" y="3" width="6" height="12" rx="3" stroke="currentColor" strokeWidth="1.8"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
  copy: (p={}) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" {...p}><rect x="8" y="8" width="12" height="12" rx="2" stroke="currentColor" strokeWidth="1.8"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3" stroke="currentColor" strokeWidth="1.8"/></svg>,
  whatsapp: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" {...p}><path d="M12 2a10 10 0 0 0-8.6 15L2 22l5.1-1.3A10 10 0 1 0 12 2zm5.4 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .1-1.7-.1-.4-.1-.9-.3-1.5-.5-2.7-1.2-4.5-3.9-4.6-4.1-.1-.2-1-1.4-1-2.6s.6-1.9.8-2.1c.2-.2.5-.3.6-.3h.5c.2 0 .4 0 .6.4.2.5.6 1.6.7 1.7.1.1.1.3 0 .5l-.3.4-.4.5c-.1.1-.3.3-.1.6.1.3.6 1.1 1.4 1.8 1 .9 1.8 1.2 2.1 1.3.3.1.5.1.6 0 .2-.2.6-.7.8-1 .2-.3.4-.2.6-.1.3.1 1.6.8 1.9 1 .3.1.5.2.5.3.1.2.1.7-.1 1.3z" fill="currentColor"/></svg>,
  sms: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><path d="M21 12a8 8 0 1 1-3.2-6.4L21 5l-1 3.5A8 8 0 0 1 21 12z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/><circle cx="9" cy="12" r="1" fill="currentColor"/><circle cx="13" cy="12" r="1" fill="currentColor"/><circle cx="17" cy="12" r="1" fill="currentColor"/></svg>,
  link: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><path d="M10 14a4 4 0 0 0 6 0l3-3a4 4 0 0 0-6-6l-1 1M14 10a4 4 0 0 0-6 0l-3 3a4 4 0 0 0 6 6l1-1" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  more: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" {...p}><circle cx="6" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="18" cy="12" r="2"/></svg>,
  star: (p={}) => <svg width="14" height="14" viewBox="0 0 24 24" {...p}><path d="M12 2l3 7 7.5.6-5.7 5 1.7 7.4L12 18l-6.5 4 1.7-7.4-5.7-5L9 9l3-7z" fill="currentColor"/></svg>,
  speaker: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><path d="M4 9v6h4l5 4V5L8 9H4z" fill="currentColor"/><path d="M16 8a5 5 0 0 1 0 8M19 5a9 9 0 0 1 0 14" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
  wifi_off: (p={}) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" {...p}><path d="M3 3l18 18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/><path d="M5 12.5a13 13 0 0 1 4-2.5M19 12.5a13 13 0 0 0-6-3.4M9 16.5a6 6 0 0 1 6 0" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/><circle cx="12" cy="20" r="1" fill="currentColor"/></svg>,
  shield: (p={}) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" {...p}><path d="M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6l8-3z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/></svg>,
  settings: (p={}) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" {...p}><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.8"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h.1a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v.1a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" stroke="currentColor" strokeWidth="1.6"/></svg>,
  layers: (p={}) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" {...p}><path d="M12 3l9 5-9 5-9-5 9-5z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/><path d="M3 13l9 5 9-5M3 17l9 5 9-5" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/></svg>,
  target: (p={}) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" {...p}><circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.8"/><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.8"/><path d="M12 1v3M12 20v3M23 12h-3M4 12H1" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
  refresh: (p={}) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" {...p}><path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  house: (p={}) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" {...p}><path d="M4 11l8-7 8 7v9a1 1 0 0 1-1 1h-4v-7h-6v7H5a1 1 0 0 1-1-1v-9z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/></svg>,
  shop: (p={}) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" {...p}><path d="M3 8l2-4h14l2 4M3 8h18v12H3V8z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/><path d="M8 12h8" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>,
  office: (p={}) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" {...p}><rect x="4" y="3" width="16" height="18" rx="1" stroke="currentColor" strokeWidth="1.8"/><path d="M9 8h.01M15 8h.01M9 12h.01M15 12h.01M9 16h.01M15 16h.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>,
  school: (p={}) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" {...p}><path d="M12 3L2 8l10 5 10-5-10-5z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/><path d="M6 10v6c0 1.5 3 3 6 3s6-1.5 6-3v-6" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/></svg>,
  hospital: (p={}) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" {...p}><rect x="3" y="6" width="18" height="14" rx="1" stroke="currentColor" strokeWidth="1.8"/><path d="M12 10v6M9 13h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/><path d="M8 6V3h8v3" stroke="currentColor" strokeWidth="1.8"/></svg>,
  church: (p={}) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" {...p}><path d="M12 2v4M10 4h4M5 21v-9l7-4 7 4v9M5 21h14M9 21v-4h6v4" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/></svg>,
  dots3: (p={}) => <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" {...p}><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>,
  qr: (p={}) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" {...p}><rect x="3" y="3" width="7" height="7" stroke="currentColor" strokeWidth="1.8"/><rect x="14" y="3" width="7" height="7" stroke="currentColor" strokeWidth="1.8"/><rect x="3" y="14" width="7" height="7" stroke="currentColor" strokeWidth="1.8"/><path d="M14 14h3v3M21 14v3M17 17v4h4" stroke="currentColor" strokeWidth="1.8"/></svg>,
};

// ─── Map background (faux satellite/street) ───────────────────
function MapSurface({ mode = 'street', height = '100%', children, style }) {
  // Street mode: dark muted with road grid. Satellite: warm earthy with blocks.
  const isSat = mode === 'satellite';
  return (
    <div style={{
      position: 'relative', width: '100%', height,
      background: isSat
        ? 'radial-gradient(120% 80% at 30% 20%, #2A2520 0%, #1A1612 60%, #14110D 100%)'
        : 'radial-gradient(120% 80% at 30% 20%, #1B1F26 0%, #131720 60%, #0E1117 100%)',
      overflow: 'hidden', ...style,
    }}>
      {/* roads / blocks */}
      <svg width="100%" height="100%" viewBox="0 0 400 700" preserveAspectRatio="xMidYMid slice" style={{ position: 'absolute', inset: 0 }}>
        <defs>
          <pattern id="blocks" width="80" height="80" patternUnits="userSpaceOnUse">
            <rect width="80" height="80" fill={isSat ? '#221C16' : '#171B23'}/>
            <rect x="6" y="6" width="30" height="30" rx="2" fill={isSat ? '#2D261E' : '#1D222C'}/>
            <rect x="44" y="6" width="30" height="22" rx="2" fill={isSat ? '#2A231C' : '#1B202A'}/>
            <rect x="6" y="44" width="22" height="30" rx="2" fill={isSat ? '#2C251D' : '#1C212B'}/>
            <rect x="36" y="44" width="38" height="30" rx="2" fill={isSat ? '#2F271F' : '#1F242E'}/>
          </pattern>
        </defs>
        <rect width="400" height="700" fill="url(#blocks)" opacity={isSat ? 0.9 : 0.7}/>
        {/* major roads */}
        <g stroke={isSat ? 'rgba(120,100,80,0.25)' : 'rgba(120,140,180,0.18)'} strokeWidth="6" fill="none">
          <path d="M0 220 L400 200"/>
          <path d="M0 480 L400 460"/>
          <path d="M160 0 L180 700"/>
        </g>
        <g stroke={isSat ? 'rgba(100,85,65,0.18)' : 'rgba(100,115,140,0.12)'} strokeWidth="2" fill="none">
          <path d="M0 100 L400 90"/>
          <path d="M0 340 L400 330"/>
          <path d="M0 600 L400 590"/>
          <path d="M60 0 L70 700"/>
          <path d="M280 0 L295 700"/>
        </g>
      </svg>
      {children}
    </div>
  );
}

// PPOINNT pin marker
function PinMarker({ size = 44, color = PP.yellow, glow = true, style }) {
  return (
    <div style={{ position: 'relative', width: size, height: size * 1.2, ...style }}>
      {glow && (
        <div style={{
          position: 'absolute', left: '50%', bottom: -4, transform: 'translateX(-50%)',
          width: size * 0.9, height: size * 0.35, borderRadius: '50%',
          background: `radial-gradient(closest-side, ${color}55, transparent)`,
          filter: 'blur(2px)',
        }}/>
      )}
      <svg width={size} height={size * 1.2} viewBox="0 0 40 48">
        <path d="M20 47s-15-16-15-27a15 15 0 1 1 30 0c0 11-15 27-15 27z" fill={color} stroke="#0A0B0D" strokeWidth="1.2"/>
        <circle cx="20" cy="19" r="6" fill="#0A0B0D"/>
      </svg>
    </div>
  );
}

// User dot
function UserDot({ size = 18 }) {
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <div style={{
        position: 'absolute', inset: -10, borderRadius: '50%',
        background: 'radial-gradient(closest-side, rgba(46,107,255,0.35), transparent)',
      }}/>
      <div style={{
        width: size, height: size, borderRadius: '50%',
        background: PP.blue, border: '3px solid #fff',
        boxShadow: '0 4px 10px rgba(46,107,255,0.5)',
      }}/>
    </div>
  );
}

// Buttons
function PrimaryBtn({ children, icon, style, onClick, dark = false }) {
  return (
    <button onClick={onClick} style={{
      width: '100%', height: 52, borderRadius: 16,
      background: PP.yellow, color: '#0A0B0D',
      border: 'none', fontFamily: PP.font, fontWeight: 700, fontSize: 15,
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      cursor: 'pointer', letterSpacing: -0.1,
      boxShadow: '0 8px 20px rgba(255,199,44,0.25)',
      ...style,
    }}>
      {icon}
      {children}
    </button>
  );
}

function SecondaryBtn({ children, icon, style }) {
  return (
    <button style={{
      width: '100%', height: 52, borderRadius: 16,
      background: PP.card, color: PP.text,
      border: `1px solid ${PP.line}`, fontFamily: PP.font, fontWeight: 600, fontSize: 15,
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      cursor: 'pointer',
      ...style,
    }}>
      {icon}
      {children}
    </button>
  );
}

// Bottom tab bar (Home/Map/Saved/Activity/Profile)
function TabBar({ active = 'home' }) {
  const tabs = [
    { id: 'home', label: 'Home', icon: I.home },
    { id: 'map', label: 'Map', icon: I.map },
    { id: 'saved', label: 'Saved', icon: I.bookmark },
    { id: 'activity', label: 'Activity', icon: I.activity },
    { id: 'profile', label: 'Profile', icon: I.user },
  ];
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-around', alignItems: 'center',
      padding: '10px 8px 24px', borderTop: `1px solid ${PP.line}`,
      background: PP.bg,
    }}>
      {tabs.map(t => {
        const on = t.id === active;
        return (
          <div key={t.id} style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
            color: on ? PP.yellow : PP.text3, padding: '4px 8px',
          }}>
            {t.icon()}
            <div style={{ fontSize: 10.5, fontWeight: on ? 700 : 500, letterSpacing: 0.1 }}>{t.label}</div>
          </div>
        );
      })}
    </div>
  );
}

// PPOINNT code chip (mono)
function CodeChip({ code, color = PP.yellow }) {
  // split into parts to color last segment
  const parts = code.split('-');
  return (
    <span style={{ fontFamily: PP.mono, fontWeight: 700, letterSpacing: 0.5 }}>
      {parts.map((p, i) => (
        <span key={i} style={{ color: i === parts.length - 1 ? color : PP.text }}>
          {p}{i < parts.length - 1 ? <span style={{ color: PP.text3 }}>-</span> : ''}
        </span>
      ))}
    </span>
  );
}

// Section header inside a screen
function ScreenHeader({ title, left, right, sub }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '52px 20px 16px 20px',
    }}>
      <div style={{ width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 12, background: PP.card, border: `1px solid ${PP.line}`, color: PP.text }}>
        {left}
      </div>
      <div style={{ flex: 1, textAlign: 'center' }}>
        <div style={{ fontSize: 16, fontWeight: 700 }}>{title}</div>
        {sub && <div style={{ fontSize: 12, color: PP.text3, marginTop: 2 }}>{sub}</div>}
      </div>
      <div style={{ width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 12, background: PP.card, border: `1px solid ${PP.line}`, color: PP.text }}>
        {right}
      </div>
    </div>
  );
}

// Expose
Object.assign(window, {
  PP, Phone, StatusBar, I, MapSurface, PinMarker, UserDot,
  PrimaryBtn, SecondaryBtn, TabBar, CodeChip, ScreenHeader,
});
