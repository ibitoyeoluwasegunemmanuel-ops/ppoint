// PPOINNT — Generate PPOINNT 5-step flow
// Step 1: Detect location
// Step 2: Move pin
// Step 3: Select place type
// Step 4: Add details (optional)
// Step 5: Review & Generate

function StepHeader({ step, total = 5, title, sub, onBack, onClose }) {
  return (
    <div style={{ padding: '52px 20px 12px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <button style={{
          width: 38, height: 38, borderRadius: 12, border: 'none',
          background: PP.card, color: PP.text, display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{I.back({ width: 18, height: 18 })}</button>
        <div style={{ fontSize: 13, color: PP.text3, fontWeight: 600 }}>Step {step} of {total}</div>
        <button style={{
          width: 38, height: 38, borderRadius: 12, border: 'none',
          background: PP.card, color: PP.text, display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{I.close({ width: 18, height: 18 })}</button>
      </div>
      {/* progress */}
      <div style={{ display: 'flex', gap: 4, marginTop: 14 }}>
        {Array.from({ length: total }, (_, i) => (
          <div key={i} style={{
            flex: 1, height: 3, borderRadius: 3,
            background: i < step ? PP.yellow : 'rgba(255,255,255,0.08)',
          }}/>
        ))}
      </div>
      <div style={{ marginTop: 22 }}>
        <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: -0.5 }}>{title}</div>
        {sub && <div style={{ fontSize: 14, color: PP.text3, marginTop: 6, lineHeight: 1.4 }}>{sub}</div>}
      </div>
    </div>
  );
}

// Step 1 — Detect
function GenStep1() {
  return (
    <Phone>
      <StepHeader step={1} title="Detect your location" sub="We'll find your current position on the map."/>
      <div style={{ flex: 1, padding: '4px 20px 20px', display: 'flex', flexDirection: 'column' }}>
        <div style={{ flex: 1, borderRadius: 22, overflow: 'hidden', position: 'relative', border: `1px solid ${PP.line}` }}>
          <MapSurface mode="street" height="100%">
            <div style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)' }}>
              {/* radar pulse */}
              <div style={{
                position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)',
                width: 120, height: 120, borderRadius: '50%',
                background: 'radial-gradient(closest-side, rgba(46,107,255,0.25), transparent)',
              }}/>
              <div style={{
                position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)',
                width: 70, height: 70, borderRadius: '50%',
                background: 'radial-gradient(closest-side, rgba(46,107,255,0.35), transparent)',
              }}/>
              <UserDot size={22}/>
            </div>
            {/* accuracy hint */}
            <div style={{
              position: 'absolute', left: 16, top: 16,
              background: 'rgba(10,11,13,0.78)', backdropFilter: 'blur(12px)',
              padding: '8px 12px', borderRadius: 12, border: `1px solid ${PP.line}`,
              display: 'flex', alignItems: 'center', gap: 8,
              fontSize: 12, fontWeight: 600,
            }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: PP.green, boxShadow: `0 0 12px ${PP.green}` }}/>
              GPS locked · ±4m
            </div>
          </MapSurface>
        </div>

        {/* Accuracy meter */}
        <div style={{
          marginTop: 14, background: PP.card, border: `1px solid ${PP.line}`,
          borderRadius: 14, padding: '12px 14px',
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, color: PP.text3, fontWeight: 600 }}>Accuracy</div>
            <div style={{ marginTop: 6, height: 4, borderRadius: 4, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
              <div style={{ width: '92%', height: '100%', background: PP.green }}/>
            </div>
          </div>
          <div style={{ fontSize: 13, fontWeight: 700, color: PP.green }}>High</div>
        </div>

        <div style={{ marginTop: 14 }}>
          <PrimaryBtn icon={I.check({ width: 18, height: 18 })}>Use this location</PrimaryBtn>
          <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, color: PP.text3, fontSize: 13, fontWeight: 600 }}>
            {I.refresh()} Detect again
          </div>
        </div>
      </div>
    </Phone>
  );
}

// Step 2 — Move pin
function GenStep2() {
  return (
    <Phone>
      <StepHeader step={2} title="Move pin to exact location" sub="Drag the pin to your entrance or gate."/>
      <div style={{ flex: 1, padding: '4px 20px 20px', display: 'flex', flexDirection: 'column' }}>
        <div style={{ flex: 1, borderRadius: 22, overflow: 'hidden', position: 'relative', border: `1px solid ${PP.line}` }}>
          <MapSurface mode="satellite" height="100%">
            {/* Pin in center with crosshair guides */}
            <div style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -100%)' }}>
              <PinMarker size={46}/>
            </div>
            {/* drag handles - subtle directional arrows */}
            <div style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)' }}>
              <div style={{
                width: 100, height: 100, borderRadius: '50%',
                border: '2px dashed rgba(255,199,44,0.35)',
              }}/>
            </div>
            {/* tip banner */}
            <div style={{
              position: 'absolute', left: 16, right: 16, bottom: 16,
              background: 'rgba(10,11,13,0.85)', backdropFilter: 'blur(20px)',
              padding: '12px 14px', borderRadius: 14, border: `1px solid ${PP.line}`,
              display: 'flex', alignItems: 'center', gap: 10,
            }}>
              <div style={{
                width: 30, height: 30, borderRadius: 9, background: PP.yellowSoft,
                color: PP.yellow, display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{I.house({ width: 16, height: 16 })}</div>
              <div style={{ flex: 1, fontSize: 12.5, color: PP.text2, lineHeight: 1.4 }}>
                For best accuracy, stand near your <span style={{ color: PP.text }}>entrance or gate</span>.
              </div>
            </div>
          </MapSurface>
        </div>
        <div style={{ marginTop: 14 }}>
          <PrimaryBtn icon={I.arrow()}>Next</PrimaryBtn>
        </div>
      </div>
    </Phone>
  );
}

// Step 3 — Select place type
function GenStep3() {
  const types = [
    { id: 'house', label: 'House', icon: I.house, active: true },
    { id: 'shop', label: 'Shop', icon: I.shop },
    { id: 'office', label: 'Office', icon: I.office },
    { id: 'school', label: 'School', icon: I.school },
    { id: 'hospital', label: 'Hospital', icon: I.hospital },
    { id: 'church', label: 'Church', icon: I.church },
    { id: 'other', label: 'Other', icon: I.more },
  ];
  return (
    <Phone>
      <StepHeader step={3} title="Select place type" sub="What kind of place is this?"/>
      <div style={{ flex: 1, padding: '8px 20px 20px', display: 'flex', flexDirection: 'column' }}>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
          {types.map(t => (
            <div key={t.id} style={{
              display: 'flex', alignItems: 'center', gap: 14,
              padding: '14px 16px',
              background: t.active ? PP.yellowSoft : PP.card,
              border: `1px solid ${t.active ? 'rgba(255,199,44,0.32)' : PP.line}`,
              borderRadius: 14,
            }}>
              <div style={{
                width: 36, height: 36, borderRadius: 10,
                background: t.active ? PP.yellow : 'rgba(255,255,255,0.05)',
                color: t.active ? '#0A0B0D' : PP.text2,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{t.icon({ width: 18, height: 18 })}</div>
              <div style={{ flex: 1, fontSize: 15, fontWeight: 600 }}>{t.label}</div>
              {t.active && (
                <div style={{
                  width: 22, height: 22, borderRadius: '50%', background: PP.yellow,
                  color: '#0A0B0D', display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>{I.check({ width: 14, height: 14 })}</div>
              )}
            </div>
          ))}
        </div>
        <div style={{ marginTop: 14 }}>
          <PrimaryBtn icon={I.arrow()}>Next</PrimaryBtn>
        </div>
      </div>
    </Phone>
  );
}

// Step 4 — Add details
function GenStep4() {
  const Field = ({ label, ph, value }) => (
    <div>
      <div style={{ fontSize: 12, color: PP.text3, fontWeight: 600, marginBottom: 8, letterSpacing: 0.1 }}>{label}</div>
      <div style={{
        height: 50, borderRadius: 14, background: PP.card,
        border: `1px solid ${value ? 'rgba(255,199,44,0.25)' : PP.line}`,
        padding: '0 14px', display: 'flex', alignItems: 'center',
        fontSize: 14, color: value ? PP.text : PP.text3,
      }}>{value || ph}</div>
    </div>
  );
  return (
    <Phone>
      <StepHeader step={4} title="Add details" sub="Help others find this place. All fields optional."/>
      <div style={{ flex: 1, padding: '8px 20px 20px', display: 'flex', flexDirection: 'column' }}>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 16, overflow: 'auto' }}>
          <Field label="Building / place name" ph="e.g. Emmanuel House" value="Emmanuel House"/>
          <Field label="Nearest landmark" ph="e.g. Beside GTBank" value="Beside GTBank"/>
          <Field label="Street / road" ph="e.g. 15, Ajani Street" value="15, Ajani Street"/>
          <div>
            <div style={{ fontSize: 12, color: PP.text3, fontWeight: 600, marginBottom: 8 }}>Additional notes</div>
            <div style={{
              height: 84, borderRadius: 14, background: PP.card, border: `1px solid ${PP.line}`,
              padding: '12px 14px', fontSize: 14, color: PP.text3,
            }}>e.g. House has brown gate, blue door</div>
          </div>
        </div>
        <div style={{ marginTop: 14 }}>
          <PrimaryBtn icon={I.arrow()}>Next</PrimaryBtn>
        </div>
      </div>
    </Phone>
  );
}

// Step 5 — Review
function GenStep5() {
  return (
    <Phone>
      <StepHeader step={5} title="Review & generate" sub="Confirm everything before creating."/>
      <div style={{ flex: 1, padding: '8px 20px 20px', display: 'flex', flexDirection: 'column' }}>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
            { k: 'Type', v: 'House', icon: I.house },
            { k: 'Location', v: 'Lagos, Nigeria', icon: I.pin },
            { k: 'Landmark', v: 'Beside GTBank', icon: I.target },
            { k: 'Street', v: '15, Ajani Street', icon: I.nav },
            { k: 'Building', v: 'Emmanuel House', icon: I.house },
          ].map((r, i) => (
            <div key={i} style={{
              background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 14,
              padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 14,
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 9,
                background: 'rgba(255,255,255,0.04)', color: PP.text3,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{r.icon({ width: 16, height: 16 })}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, color: PP.text3, fontWeight: 600 }}>{r.k}</div>
                <div style={{ fontSize: 14, fontWeight: 600, marginTop: 2 }}>{r.v}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 14 }}>
          <PrimaryBtn icon={I.arrow()}>Generate PPOINNT</PrimaryBtn>
          <div style={{ marginTop: 10, textAlign: 'center', fontSize: 13, color: PP.text3, fontWeight: 600 }}>Edit details</div>
        </div>
      </div>
    </Phone>
  );
}

Object.assign(window, { GenStep1, GenStep2, GenStep3, GenStep4, GenStep5 });
