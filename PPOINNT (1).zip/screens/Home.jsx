// PPOINNT — Home screen (main map + bottom sheet)
function HomeScreen() {
  return (
    <Phone>
      {/* Map background fills entire screen */}
      <div style={{ position: 'absolute', inset: 0 }}>
        <MapSurface mode="street" height="100%">
          {/* user dot */}
          <div style={{ position: 'absolute', left: '50%', top: '32%', transform: 'translate(-50%, -50%)' }}>
            <UserDot />
          </div>
          {/* nearby pins */}
          <div style={{ position: 'absolute', left: '28%', top: '24%' }}><PinMarker size={28} color={PP.yellow} glow={false}/></div>
          <div style={{ position: 'absolute', left: '70%', top: '18%' }}><PinMarker size={26} color="rgba(255,199,44,0.55)" glow={false}/></div>
          <div style={{ position: 'absolute', left: '58%', top: '34%' }}><PinMarker size={26} color="rgba(255,199,44,0.55)" glow={false}/></div>
        </MapSurface>
        {/* dim overlay at bottom */}
        <div style={{
          position: 'absolute', left: 0, right: 0, bottom: 0, height: '60%',
          background: 'linear-gradient(to bottom, rgba(10,11,13,0) 0%, rgba(10,11,13,0.85) 35%, #0A0B0D 70%)',
        }}/>
      </div>

      {/* Top bar */}
      <div style={{ position: 'relative', zIndex: 5, padding: '52px 20px 0' }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <button style={{
            width: 44, height: 44, borderRadius: 14, border: 'none',
            background: 'rgba(20,22,28,0.7)', backdropFilter: 'blur(20px)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: PP.text, cursor: 'pointer',
          }}>{I.menu()}</button>

          <div style={{
            flex: 1, height: 44, borderRadius: 14,
            background: 'rgba(20,22,28,0.7)', backdropFilter: 'blur(20px)',
            display: 'flex', alignItems: 'center', padding: '0 14px', gap: 10,
            color: PP.text3,
          }}>
            <span style={{ color: PP.text3 }}>{I.search()}</span>
            <span style={{ flex: 1, fontSize: 14, color: PP.text3 }}>Search PPOINNT or place</span>
            <div style={{
              width: 28, height: 28, borderRadius: 8, background: PP.yellow,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <div style={{ color: '#0A0B0D' }}>{I.mic({ width: 16, height: 16 })}</div>
            </div>
          </div>
        </div>

        {/* Guidance banner */}
        <div style={{
          marginTop: 16, padding: '10px 14px', borderRadius: 12,
          background: 'rgba(255,199,44,0.08)',
          border: '1px solid rgba(255,199,44,0.18)',
          display: 'flex', alignItems: 'center', gap: 10,
          backdropFilter: 'blur(20px)',
        }}>
          <div style={{ color: PP.yellow, display: 'flex' }}>{I.target({ width: 16, height: 16 })}</div>
          <div style={{ flex: 1, fontSize: 12, color: 'rgba(255,255,255,0.85)', lineHeight: 1.4 }}>
            Stand near your entrance for the most accurate PPOINNT.
          </div>
        </div>
      </div>

      {/* Floating map controls */}
      <div style={{
        position: 'absolute', right: 16, top: 220, zIndex: 5,
        display: 'flex', flexDirection: 'column', gap: 8,
      }}>
        {[I.layers, I.target].map((Icn, i) => (
          <button key={i} style={{
            width: 40, height: 40, borderRadius: 12, border: `1px solid ${PP.line}`,
            background: 'rgba(20,22,28,0.85)', backdropFilter: 'blur(20px)',
            color: PP.text, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
          }}>{Icn()}</button>
        ))}
      </div>

      {/* Bottom sheet */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 10,
        background: PP.bg,
        borderTopLeftRadius: 28, borderTopRightRadius: 28,
        padding: '10px 0 0',
      }}>
        {/* grab handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '6px 0 14px' }}>
          <div style={{ width: 40, height: 4, borderRadius: 4, background: 'rgba(255,255,255,0.18)' }}/>
        </div>

        {/* Greeting */}
        <div style={{ padding: '0 20px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: 13, color: PP.text3, fontWeight: 500 }}>Good evening, Emmanuel</div>
            <div style={{ fontSize: 20, fontWeight: 700, marginTop: 2, letterSpacing: -0.3 }}>Where to?</div>
          </div>
          <div style={{
            width: 40, height: 40, borderRadius: 12,
            background: PP.card, border: `1px solid ${PP.line}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            position: 'relative',
          }}>
            {I.bell({ width: 18, height: 18 })}
            <span style={{
              position: 'absolute', top: 8, right: 9, width: 8, height: 8, borderRadius: '50%',
              background: PP.yellow, border: '2px solid ' + PP.bg,
            }}/>
          </div>
        </div>

        {/* Generate PPOINNT — hero CTA */}
        <div style={{ padding: '0 20px 14px' }}>
          <div style={{
            background: `linear-gradient(135deg, ${PP.yellow} 0%, #FFB400 100%)`,
            borderRadius: 20, padding: '16px 18px',
            display: 'flex', alignItems: 'center', gap: 14,
            color: '#0A0B0D', cursor: 'pointer',
            boxShadow: '0 12px 28px rgba(255,199,44,0.22)',
            position: 'relative', overflow: 'hidden',
          }}>
            {/* decorative pin echo */}
            <div style={{ position: 'absolute', right: -10, bottom: -16, opacity: 0.18 }}>
              <PinMarker size={90} color="#0A0B0D" glow={false}/>
            </div>
            <div style={{
              width: 48, height: 48, borderRadius: 14,
              background: 'rgba(10,11,13,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {I.plus({ width: 24, height: 24 })}
            </div>
            <div style={{ flex: 1, position: 'relative', zIndex: 1 }}>
              <div style={{ fontSize: 16, fontWeight: 800, letterSpacing: -0.3 }}>Generate PPOINNT</div>
              <div style={{ fontSize: 12.5, opacity: 0.7, fontWeight: 500, marginTop: 2 }}>Pin your exact entrance</div>
            </div>
            <div style={{ color: '#0A0B0D', position: 'relative', zIndex: 1 }}>{I.arrow()}</div>
          </div>
        </div>

        {/* Quick actions row */}
        <div style={{ padding: '0 20px 18px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
          {[
            { label: 'Navigate', icon: I.nav, accent: PP.blue },
            { label: 'Share', icon: I.share, accent: PP.text },
            { label: 'Scan', icon: I.scan, accent: PP.text },
          ].map((a, i) => (
            <div key={i} style={{
              background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 16,
              padding: '14px 10px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
            }}>
              <div style={{
                width: 36, height: 36, borderRadius: 10,
                background: i === 0 ? PP.blueSoft : 'rgba(255,255,255,0.05)',
                color: a.accent, display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{a.icon({ width: 18, height: 18 })}</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: PP.text2 }}>{a.label}</div>
            </div>
          ))}
        </div>

        {/* Recent PPOINNTs */}
        <div style={{ padding: '0 20px 8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: PP.text2, textTransform: 'uppercase', letterSpacing: 0.6 }}>Recent</div>
          <div style={{ fontSize: 12, color: PP.yellow, fontWeight: 600 }}>View all</div>
        </div>

        <div style={{ padding: '6px 20px 10px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
            { code: 'PPT-NG-LAG-IKD-1234', name: '15, Abraham Adesanya, Lekki', time: '2 min ago', type: I.house },
            { code: 'PPT-NG-LAG-YBA-5678', name: '23, Kudirat Abiola, Oregun', time: '1 hr ago', type: I.shop },
          ].map((r, i) => (
            <div key={i} style={{
              background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 14,
              padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{
                width: 38, height: 38, borderRadius: 11,
                background: PP.yellowSoft, color: PP.yellow,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{r.type({ width: 18, height: 18 })}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontFamily: PP.mono, fontWeight: 700, letterSpacing: 0.3 }}>
                  <CodeChip code={r.code}/>
                </div>
                <div style={{ fontSize: 12, color: PP.text3, marginTop: 3, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.name}</div>
              </div>
              <div style={{ fontSize: 11, color: PP.text3, whiteSpace: 'nowrap' }}>{r.time}</div>
            </div>
          ))}
        </div>

        <TabBar active="home"/>
      </div>
    </Phone>
  );
}

window.HomeScreen = HomeScreen;
