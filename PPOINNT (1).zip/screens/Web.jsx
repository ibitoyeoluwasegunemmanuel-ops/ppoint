// PPOINNT — Web / desktop adaptation of the new design language
// Replaces the map-heavy "formal" desktop layout with a focused dashboard
// shell: sidebar nav, command-style search, floating map preview, contextual
// side panel — same dark + yellow + electric-blue system as the mobile screens.

function WebDashboard() {
  return (
    <div style={{
      width: '100%', height: '100%', background: PP.bg, color: PP.text,
      fontFamily: PP.font, display: 'grid', gridTemplateColumns: '232px 1fr 360px',
      borderRadius: 18, overflow: 'hidden', border: `1px solid ${PP.line}`,
    }}>
      {/* ─── Sidebar ─────────────────────────────────────────── */}
      <aside style={{
        background: '#0E1014', borderRight: `1px solid ${PP.line}`,
        padding: '22px 14px', display: 'flex', flexDirection: 'column', gap: 6,
      }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 6px 18px' }}>
          <div style={{ width: 32, height: 32, borderRadius: 9, background: PP.yellow, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="18" height="18" viewBox="0 0 24 24"><path d="M12 22s-7-7.5-7-13a7 7 0 1 1 14 0c0 5.5-7 13-7 13z" fill="#0A0B0D"/><circle cx="12" cy="9" r="2.5" fill={PP.yellow}/></svg>
          </div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 800, letterSpacing: -0.2 }}>PPOINNT</div>
            <div style={{ fontSize: 10, color: PP.text3, fontWeight: 600, letterSpacing: 0.4 }}>ppoint.africa</div>
          </div>
        </div>

        {/* primary nav */}
        {[
          { l: 'Overview', i: I.home, on: true },
          { l: 'Addresses', i: I.pin, badge: '128' },
          { l: 'Live map', i: I.map },
          { l: 'Navigation', i: I.nav },
          { l: 'Agents', i: I.user },
          { l: 'Activity', i: I.activity },
        ].map((n, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 11, padding: '9px 10px', borderRadius: 10,
            background: n.on ? PP.yellowSoft : 'transparent', color: n.on ? PP.yellow : PP.text2,
            fontSize: 13, fontWeight: 600, cursor: 'pointer',
          }}>
            {n.i({ width: 17, height: 17 })}
            <span style={{ flex: 1 }}>{n.l}</span>
            {n.badge && (
              <span style={{
                padding: '2px 7px', background: 'rgba(255,255,255,0.06)',
                borderRadius: 6, fontSize: 10.5, fontWeight: 700, color: PP.text3,
              }}>{n.badge}</span>
            )}
          </div>
        ))}

        <div style={{ height: 18 }}/>
        <div style={{ padding: '0 8px 6px', fontSize: 10, color: PP.text3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.7 }}>Workspace</div>
        {[
          { l: 'API & SDK', i: I.scan },
          { l: 'Team', i: I.shield },
          { l: 'Settings', i: I.settings },
        ].map((n, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 11, padding: '9px 10px', borderRadius: 10,
            color: PP.text2, fontSize: 13, fontWeight: 600,
          }}>
            {n.i({ width: 17, height: 17 })}
            <span style={{ flex: 1 }}>{n.l}</span>
          </div>
        ))}

        <div style={{ flex: 1 }}/>

        {/* Workspace card */}
        <div style={{
          background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 14, padding: '12px',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 11,
            background: 'linear-gradient(135deg, #3F2E1E 0%, #5C3F1F 100%)',
            color: PP.yellow, fontWeight: 800, fontSize: 13,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            border: '1.5px solid rgba(255,199,44,0.4)',
          }}>EO</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12.5, fontWeight: 700 }}>Emmanuel O.</div>
            <div style={{ fontSize: 10.5, color: PP.text3, marginTop: 1 }}>Silver agent</div>
          </div>
          <div style={{ color: PP.text3 }}>{I.chevR()}</div>
        </div>
      </aside>

      {/* ─── Main content ─────────────────────────────────────── */}
      <main style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {/* Top bar */}
        <header style={{
          padding: '18px 28px', borderBottom: `1px solid ${PP.line}`,
          display: 'flex', alignItems: 'center', gap: 14,
        }}>
          <div style={{
            flex: 1, height: 42, borderRadius: 12, background: PP.card,
            border: `1px solid ${PP.line}`, padding: '0 14px',
            display: 'flex', alignItems: 'center', gap: 10, color: PP.text3,
          }}>
            {I.search({ width: 18, height: 18 })}
            <span style={{ fontSize: 13.5, flex: 1 }}>Search PPOINNT code, street, or place</span>
            <span style={{ fontSize: 11, padding: '3px 6px', borderRadius: 5, background: 'rgba(255,255,255,0.06)', color: PP.text3, fontFamily: PP.mono, fontWeight: 700 }}>⌘K</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <button style={iconBtn}>{I.bell({ width: 18, height: 18 })}</button>
            <button style={{ ...iconBtn, background: PP.yellow, color: '#0A0B0D', borderColor: PP.yellow, padding: '0 16px', width: 'auto', fontWeight: 800, fontSize: 13, gap: 8 }}>
              {I.plus({ width: 16, height: 16 })} Generate PPOINNT
            </button>
          </div>
        </header>

        {/* Content area */}
        <div style={{ flex: 1, overflow: 'auto', padding: '24px 28px' }}>
          {/* Title row */}
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontSize: 12, color: PP.text3, fontWeight: 600 }}>Good evening, Emmanuel</div>
              <div style={{ fontSize: 26, fontWeight: 800, letterSpacing: -0.5, marginTop: 4 }}>Ikorodu territory · live</div>
            </div>
            <div style={{ display: 'flex', gap: 6, background: PP.card, padding: 4, borderRadius: 10, border: `1px solid ${PP.line}` }}>
              {['Today', 'Week', 'Month', 'All time'].map((p, i) => (
                <div key={i} style={{
                  padding: '6px 12px', borderRadius: 7, fontSize: 12, fontWeight: 700,
                  background: i === 1 ? PP.yellow : 'transparent', color: i === 1 ? '#0A0B0D' : PP.text2,
                }}>{p}</div>
              ))}
            </div>
          </div>

          {/* KPI grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginTop: 18 }}>
            {[
              { k: 'PPOINNTs created', v: '128', delta: '+12%', accent: PP.yellow, spark: [4, 6, 5, 8, 7, 10, 12] },
              { k: 'Verified', v: '94', delta: '+8%', accent: PP.green, spark: [2, 3, 5, 4, 6, 7, 8] },
              { k: 'Earnings · ₦', v: '24,650', delta: '+₦2,150', accent: PP.yellow, spark: [3, 5, 4, 6, 8, 7, 9] },
              { k: 'Accuracy score', v: '98%', delta: '↑ 2 ranks', accent: PP.blue, spark: [6, 7, 6, 8, 8, 9, 10] },
            ].map((s, i) => (
              <div key={i} style={{
                background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 16, padding: '14px 16px',
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ fontSize: 11.5, color: PP.text3, fontWeight: 600 }}>{s.k}</div>
                  <Spark data={s.spark} color={s.accent}/>
                </div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 8 }}>
                  <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: -0.5 }}>{s.v}</div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: s.accent }}>{s.delta}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Map + table */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 10, marginTop: 12 }}>
            {/* Map */}
            <div style={{
              background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 18,
              overflow: 'hidden', position: 'relative', height: 360,
            }}>
              <MapSurface mode="street" height="100%">
                {/* territory polygon */}
                <svg width="100%" height="100%" viewBox="0 0 600 360" preserveAspectRatio="xMidYMid slice" style={{ position: 'absolute', inset: 0 }}>
                  <path d="M80 80 L440 60 L520 200 L380 300 L120 280 Z" fill="rgba(255,199,44,0.14)" stroke={PP.yellow} strokeWidth="1.5" strokeDasharray="4 4"/>
                </svg>
                {[[150, 130], [240, 100], [320, 170], [400, 140], [200, 220], [340, 240], [430, 220]].map(([x, y], i) => (
                  <div key={i} style={{ position: 'absolute', left: x, top: y }}>
                    <PinMarker size={22} glow={false}/>
                  </div>
                ))}
                <div style={{ position: 'absolute', left: 270, top: 200 }}><UserDot size={18}/></div>

                {/* Floating overlay card */}
                <div style={{
                  position: 'absolute', left: 16, top: 16, padding: '10px 14px',
                  background: 'rgba(14,16,20,0.9)', backdropFilter: 'blur(20px)',
                  border: `1px solid ${PP.line}`, borderRadius: 12,
                  display: 'flex', alignItems: 'center', gap: 10,
                }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: PP.green, boxShadow: `0 0 12px ${PP.green}` }}/>
                  <span style={{ fontSize: 12, fontWeight: 700 }}>7 PPOINNTs live</span>
                  <span style={{ fontSize: 11, color: PP.text3 }}>· Ikorodu · 14 km²</span>
                </div>

                {/* layer toggle */}
                <div style={{
                  position: 'absolute', right: 16, top: 16,
                  display: 'flex', gap: 4, padding: 4, borderRadius: 10,
                  background: 'rgba(14,16,20,0.9)', backdropFilter: 'blur(20px)',
                  border: `1px solid ${PP.line}`,
                }}>
                  {['Map', 'Satellite', 'Hybrid'].map((m, i) => (
                    <div key={i} style={{
                      padding: '5px 10px', borderRadius: 7,
                      background: i === 0 ? PP.yellow : 'transparent',
                      color: i === 0 ? '#0A0B0D' : PP.text2,
                      fontSize: 11, fontWeight: 700, cursor: 'pointer',
                    }}>{m}</div>
                  ))}
                </div>
              </MapSurface>
            </div>

            {/* Recent activity */}
            <div style={{
              background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 18,
              padding: '14px 16px', display: 'flex', flexDirection: 'column',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>Recent PPOINNTs</div>
                <div style={{ fontSize: 11, color: PP.yellow, fontWeight: 700 }}>View all →</div>
              </div>
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 6, flex: 1, overflow: 'auto' }}>
                {[
                  { c: 'PPT-NG-LAG-IKD-1234', n: '15, Ajani Street', s: 'verified', when: '2m' },
                  { c: 'PPT-NG-LAG-IKD-1235', n: '12, Soyinka Street', s: 'live', when: '8m' },
                  { c: 'PPT-NG-LAG-IKD-1236', n: 'Igbobi College', s: 'live', when: '21m' },
                  { c: 'PPT-NG-LAG-IKD-1237', n: '8, Oniya Street', s: 'pending', when: '34m' },
                  { c: 'PPT-NG-LAG-IKD-1238', n: 'Medical Centre', s: 'verified', when: '1h' },
                  { c: 'PPT-NG-LAG-IKD-1239', n: 'Akoka entrance', s: 'live', when: '2h' },
                ].map((r, i) => {
                  const c = { verified: PP.green, live: PP.yellow, pending: PP.amber }[r.s];
                  return (
                    <div key={i} style={{
                      padding: '8px 4px', display: 'flex', alignItems: 'center', gap: 10,
                      borderBottom: i < 5 ? `1px solid ${PP.line}` : 'none',
                    }}>
                      <span style={{ width: 6, height: 6, borderRadius: '50%', background: c }}/>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 11.5, fontFamily: PP.mono, fontWeight: 700 }}><CodeChip code={r.c}/></div>
                        <div style={{ fontSize: 11, color: PP.text3, marginTop: 2 }}>{r.n}</div>
                      </div>
                      <div style={{ fontSize: 10.5, color: PP.text3 }}>{r.when}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Data table */}
          <div style={{
            marginTop: 10, background: PP.card, border: `1px solid ${PP.line}`,
            borderRadius: 18, overflow: 'hidden',
          }}>
            <div style={{
              padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              borderBottom: `1px solid ${PP.line}`,
            }}>
              <div style={{ fontSize: 13, fontWeight: 700 }}>Agent leaderboard · Ikorodu</div>
              <div style={{ fontSize: 11.5, color: PP.text3, fontWeight: 600 }}>Top 5 of 142 this month</div>
            </div>
            <div>
              {[
                { r: 1, n: 'Adaeze N.', c: 184, acc: '99%', earn: '₦38,400', t: PP.yellow },
                { r: 2, n: 'Tunde A.', c: 156, acc: '98%', earn: '₦32,100', t: PP.text2 },
                { r: 3, n: 'Emmanuel O.', c: 128, acc: '98%', earn: '₦24,650', t: PP.text2, me: true },
                { r: 4, n: 'Ifeoma K.', c: 112, acc: '97%', earn: '₦22,800', t: PP.text2 },
                { r: 5, n: 'Samuel B.', c: 94, acc: '96%', earn: '₦19,200', t: PP.text2 },
              ].map((row, i) => (
                <div key={i} style={{
                  padding: '11px 16px', display: 'grid', gridTemplateColumns: '36px 1fr 100px 100px 110px',
                  alignItems: 'center', gap: 12,
                  background: row.me ? 'rgba(255,199,44,0.04)' : 'transparent',
                  borderTop: i > 0 ? `1px solid ${PP.line}` : 'none',
                }}>
                  <div style={{
                    width: 26, height: 26, borderRadius: 8, background: row.r === 1 ? PP.yellow : 'rgba(255,255,255,0.04)',
                    color: row.r === 1 ? '#0A0B0D' : PP.text2, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontWeight: 800, fontSize: 12,
                  }}>{row.r}</div>
                  <div style={{ fontSize: 13, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8 }}>
                    {row.n}
                    {row.me && <span style={{ padding: '2px 7px', borderRadius: 5, background: PP.yellowSoft, color: PP.yellow, fontSize: 10, fontWeight: 800 }}>you</span>}
                  </div>
                  <div style={{ fontSize: 12.5, fontWeight: 700, color: PP.text2 }}>{row.c} created</div>
                  <div style={{ fontSize: 12.5, fontWeight: 700, color: PP.green }}>{row.acc}</div>
                  <div style={{ fontSize: 12.5, fontWeight: 800, textAlign: 'right' }}>{row.earn}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* ─── Right rail ──────────────────────────────────────── */}
      <aside style={{
        background: '#0E1014', borderLeft: `1px solid ${PP.line}`,
        padding: '22px 18px', display: 'flex', flexDirection: 'column', gap: 12, overflow: 'auto',
      }}>
        <div style={{ fontSize: 11, color: PP.text3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.7 }}>Inspector · selection</div>

        {/* Selected PPOINNT */}
        <div style={{
          background: 'linear-gradient(135deg, #1A1D24 0%, #14171C 100%)',
          border: `1px solid ${PP.line}`, borderRadius: 16, padding: '14px 16px',
          position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', right: -12, top: -8, opacity: 0.18 }}><PinMarker size={70} glow={false}/></div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: PP.green, boxShadow: `0 0 10px ${PP.green}` }}/>
            <span style={{ fontSize: 10.5, fontWeight: 700, color: PP.green, textTransform: 'uppercase', letterSpacing: 0.5 }}>Verified · live</span>
          </div>
          <div style={{ fontSize: 18, fontWeight: 800, fontFamily: PP.mono, marginTop: 8, letterSpacing: 0.5 }}>
            <CodeChip code="PPT-NG-LAG-IKD-1234"/>
          </div>
          <div style={{ fontSize: 12.5, color: PP.text2, marginTop: 6, lineHeight: 1.45 }}>15, Ajani Street<br/>Ikorodu, Lagos</div>
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          <button style={{ ...iconBtn, flex: 1, width: 'auto', padding: '0 12px', gap: 8, fontSize: 12.5, fontWeight: 700, color: '#0A0B0D', background: PP.yellow, borderColor: PP.yellow }}>
            {I.nav({ width: 15, height: 15 })} Navigate
          </button>
          <button style={{ ...iconBtn, flex: 1, width: 'auto', padding: '0 12px', gap: 8, fontSize: 12.5, fontWeight: 700 }}>
            {I.share({ width: 15, height: 15 })} Share
          </button>
        </div>

        {/* Meta */}
        <div style={{ background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 14, padding: 4 }}>
          {[
            ['Type', 'House'],
            ['Landmark', 'Beside GTBank'],
            ['Created by', 'Adaeze N.'],
            ['Last verified', '2 hr ago'],
            ['Accuracy', 'High · ±3m', PP.green],
            ['Used', '47 times'],
          ].map(([k, v, c], i, arr) => (
            <div key={i} style={{
              padding: '9px 12px', display: 'flex', justifyContent: 'space-between',
              borderBottom: i < arr.length - 1 ? `1px solid ${PP.line}` : 'none',
              fontSize: 12,
            }}>
              <span style={{ color: PP.text3, fontWeight: 600 }}>{k}</span>
              <span style={{ fontWeight: 700, color: c || PP.text }}>{v}</span>
            </div>
          ))}
        </div>

        {/* QR */}
        <div style={{
          background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 14,
          padding: 14, display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{ width: 70, height: 70, borderRadius: 9, background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <MiniQR/>
          </div>
          <div>
            <div style={{ fontSize: 11.5, fontWeight: 700, color: PP.text3 }}>QR · ppoint.online/p/IKD1234</div>
            <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
              <span style={{ padding: '4px 8px', borderRadius: 6, background: 'rgba(255,255,255,0.05)', fontSize: 10.5, fontWeight: 700, color: PP.text2 }}>Download</span>
              <span style={{ padding: '4px 8px', borderRadius: 6, background: 'rgba(255,255,255,0.05)', fontSize: 10.5, fontWeight: 700, color: PP.text2 }}>Copy</span>
            </div>
          </div>
        </div>

        {/* API */}
        <div style={{
          background: '#0A0B0D', border: `1px solid ${PP.line}`, borderRadius: 14, padding: 14,
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: PP.text3, textTransform: 'uppercase', letterSpacing: 0.6 }}>API · GET</div>
          <div style={{
            marginTop: 8, fontFamily: PP.mono, fontSize: 11.5, lineHeight: 1.6,
            color: PP.text2,
          }}>
            <div><span style={{ color: PP.yellow }}>curl</span> ppoint.africa/v1/<br/></div>
            <div style={{ paddingLeft: 18 }}>resolve/<span style={{ color: PP.blue }}>PPT-NG-LAG-IKD-1234</span></div>
          </div>
        </div>
      </aside>
    </div>
  );
}

const iconBtn = {
  width: 42, height: 42, borderRadius: 11, background: PP.card,
  border: `1px solid ${PP.line}`, color: PP.text,
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  cursor: 'pointer', fontFamily: PP.font,
};

// Mini sparkline
function Spark({ data, color }) {
  const w = 56, h = 22, max = Math.max(...data), min = Math.min(...data);
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / Math.max(1, max - min)) * h;
    return `${x},${y}`;
  }).join(' ');
  return (
    <svg width={w} height={h}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

function MiniQR() {
  const size = 13;
  const cell = 60 / size;
  const cells = [];
  for (let i = 0; i < size; i++) for (let j = 0; j < size; j++) {
    const inFinder = (i < 4 && j < 4) || (i < 4 && j > size - 5) || (i > size - 5 && j < 4);
    if (inFinder) continue;
    if (((i * 7 + j * 5 + i * j) % 5) < 2) cells.push([i, j]);
  }
  return (
    <svg width="60" height="60" viewBox="0 0 60 60">
      {cells.map(([i, j], k) => <rect key={k} x={j * cell} y={i * cell} width={cell - 0.4} height={cell - 0.4} fill="#0A0B0D" rx="0.6"/>)}
      {[[0, 0], [60 - cell * 4, 0], [0, 60 - cell * 4]].map(([x, y], k) => (
        <g key={k}>
          <rect x={x} y={y} width={cell * 4} height={cell * 4} fill="#0A0B0D" rx={2}/>
          <rect x={x + cell * 0.7} y={y + cell * 0.7} width={cell * 2.6} height={cell * 2.6} fill="#fff" rx={1}/>
          <rect x={x + cell * 1.4} y={y + cell * 1.4} width={cell * 1.2} height={cell * 1.2} fill="#0A0B0D"/>
        </g>
      ))}
    </svg>
  );
}

window.WebDashboard = WebDashboard;
