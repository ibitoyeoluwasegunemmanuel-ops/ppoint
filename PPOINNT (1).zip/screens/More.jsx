// PPOINNT — Agent dashboard + Profile + Low network + Activity

function AgentScreen() {
  return (
    <Phone>
      <ScreenHeader title="Agent Dashboard" left={I.menu({ width: 18, height: 18 })} right={I.bell({ width: 18, height: 18 })}/>

      <div style={{ flex: 1, overflow: 'auto', padding: '4px 20px 20px' }}>
        {/* Earnings hero */}
        <div style={{
          background: `linear-gradient(135deg, #1A1D24 0%, #14171C 100%)`,
          border: `1px solid ${PP.line}`, borderRadius: 22, padding: '18px 18px 16px',
          position: 'relative', overflow: 'hidden',
        }}>
          {/* glow */}
          <div style={{
            position: 'absolute', top: -30, right: -30, width: 160, height: 160,
            background: 'radial-gradient(closest-side, rgba(255,199,44,0.25), transparent)',
          }}/>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ fontSize: 12, color: PP.text3, fontWeight: 600 }}>Earnings balance</div>
            <div style={{
              padding: '5px 10px', borderRadius: 8, background: PP.yellow, color: '#0A0B0D',
              fontSize: 11.5, fontWeight: 800, letterSpacing: 0.1,
            }}>Withdraw</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 8, position: 'relative' }}>
            <div style={{ fontSize: 14, color: PP.text2, fontWeight: 600 }}>₦</div>
            <div style={{ fontSize: 36, fontWeight: 800, letterSpacing: -0.8, lineHeight: 1 }}>24,650</div>
            <div style={{ fontSize: 18, color: PP.text2, fontWeight: 700 }}>.00</div>
          </div>
          <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M7 14l5-5 5 5" stroke="#23C57A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
            <span style={{ fontSize: 12, color: PP.green, fontWeight: 700 }}>+₦2,150 this week</span>
            <span style={{ fontSize: 12, color: PP.text3, fontWeight: 500 }}>· Instant payout enabled</span>
          </div>
        </div>

        {/* Stats row */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 10 }}>
          {[
            { v: '128', l: 'PPOINNT created', sub: 'This month', accent: PP.yellow },
            { v: '₦48,230', l: 'Total earned', sub: 'All time', accent: PP.green },
          ].map((s, i) => (
            <div key={i} style={{
              background: PP.card, border: `1px solid ${PP.line}`,
              borderRadius: 18, padding: '14px 16px',
            }}>
              <div style={{ fontSize: 11.5, color: PP.text3, fontWeight: 600 }}>{s.l}</div>
              <div style={{ fontSize: 22, fontWeight: 800, marginTop: 6, letterSpacing: -0.4 }}>{s.v}</div>
              <div style={{ fontSize: 11, color: PP.text3, marginTop: 3, fontWeight: 500 }}>{s.sub}</div>
            </div>
          ))}
        </div>

        {/* Territory */}
        <div style={{
          marginTop: 10, background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 18, padding: '14px 16px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontSize: 11.5, color: PP.text3, fontWeight: 600 }}>Your territory</div>
              <div style={{ fontSize: 16, fontWeight: 700, marginTop: 4 }}>Ikorodu, Lagos</div>
            </div>
            <div style={{
              padding: '6px 12px', borderRadius: 9, background: 'rgba(255,255,255,0.04)',
              fontSize: 11.5, fontWeight: 700, color: PP.text2,
            }}>Change</div>
          </div>
          {/* territory map preview */}
          <div style={{
            marginTop: 12, height: 92, borderRadius: 12, position: 'relative', overflow: 'hidden',
            background: '#1B1F26',
          }}>
            <MapSurface mode="street" height="100%"/>
            <svg width="100%" height="100%" viewBox="0 0 300 92" preserveAspectRatio="xMidYMid slice" style={{ position: 'absolute', inset: 0 }}>
              <path d="M50 20 L210 14 L260 60 L150 84 L40 70 Z" fill="rgba(255,199,44,0.22)" stroke={PP.yellow} strokeWidth="1.8" strokeLinejoin="round"/>
              <circle cx="150" cy="48" r="3" fill={PP.yellow}/>
            </svg>
          </div>
        </div>

        {/* Performance */}
        <div style={{
          marginTop: 10, background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 18, padding: '14px 16px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ fontSize: 11.5, color: PP.text3, fontWeight: 600 }}>Performance · Accuracy score</div>
            <div style={{ fontSize: 12, fontWeight: 700, color: PP.green, display: 'flex', alignItems: 'center', gap: 4 }}>
              {I.star({ width: 12, height: 12 })} Silver Agent
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 8 }}>
            <div style={{ fontSize: 28, fontWeight: 800, letterSpacing: -0.6 }}>98%</div>
            <div style={{ fontSize: 12, color: PP.text3, fontWeight: 600 }}>· rank #14 in Ikorodu</div>
          </div>
          <div style={{ marginTop: 10, height: 6, borderRadius: 6, background: 'rgba(255,255,255,0.05)', overflow: 'hidden' }}>
            <div style={{ width: '98%', height: '100%', background: `linear-gradient(90deg, ${PP.green}, #5EE6A0)` }}/>
          </div>
        </div>

        {/* Verification task */}
        <div style={{
          marginTop: 10, background: 'rgba(46,107,255,0.07)', border: '1px solid rgba(46,107,255,0.22)',
          borderRadius: 18, padding: '14px 16px',
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 11, background: PP.blueSoft, color: PP.blue,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>{I.shield()}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13.5, fontWeight: 700 }}>3 PPOINNTs to verify</div>
            <div style={{ fontSize: 11.5, color: PP.text3, marginTop: 2 }}>Earn ₦500 per verification</div>
          </div>
          <div style={{ color: PP.text2 }}>{I.chevR()}</div>
        </div>

        <div style={{ height: 70 }}/>
      </div>

      {/* Agent tab bar */}
      <div style={{ borderTop: `1px solid ${PP.line}`, background: PP.bg, padding: '10px 8px 24px', display: 'flex', justifyContent: 'space-around' }}>
        {[
          { id: 'd', l: 'Dashboard', i: I.activity, on: true },
          { id: 'a', l: 'Addresses', i: I.pin },
          { id: 'e', l: 'Earnings', i: I.bookmark },
          { id: 't', l: 'Tasks', i: I.shield },
          { id: 'p', l: 'Profile', i: I.user },
        ].map(t => (
          <div key={t.id} style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
            color: t.on ? PP.yellow : PP.text3,
          }}>
            {t.i()}
            <div style={{ fontSize: 10, fontWeight: t.on ? 700 : 500 }}>{t.l}</div>
          </div>
        ))}
      </div>
    </Phone>
  );
}

// Activity screen — earnings log
function ActivityScreen() {
  const items = [
    { type: 'use', code: 'PPT-NG-LAG-IKD-1234', desc: 'by delivery partner', amt: '+₦50.00', when: '2 min ago', color: PP.yellow },
    { type: 'verify', code: 'PPT-NG-LAG-IKD-1234', desc: 'Address verified', amt: '+₦500.00', when: '1 hr ago', color: PP.green },
    { type: 'create', code: 'PPT-NG-LAG-YBA-5678', desc: 'PPOINNT created', amt: '+₦50.00', when: '3 hrs ago', color: PP.yellow },
    { type: 'use', code: 'PPT-NG-LAG-YBA-5678', desc: 'by delivery partner', amt: '+₦50.00', when: '5 hrs ago', color: PP.yellow },
    { type: 'create', code: 'PPT-NG-ABJ-GRK-9012', desc: 'PPOINNT created', amt: '+₦50.00', when: 'Yesterday', color: PP.yellow },
  ];
  return (
    <Phone>
      <div style={{ padding: '52px 20px 12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: -0.5 }}>Activity</div>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '8px 12px', borderRadius: 12, background: PP.card, border: `1px solid ${PP.line}`,
            fontSize: 12.5, fontWeight: 600,
          }}>
            All {I.chevD({ width: 12, height: 12 })}
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '0 20px 80px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {/* Today badge */}
        <div style={{ fontSize: 11, color: PP.text3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6, marginTop: 4, marginBottom: 4 }}>Today</div>
        {items.map((a, i) => (
          <div key={i} style={{
            background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 14,
            padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{
              width: 38, height: 38, borderRadius: 11, background: PP.yellowSoft, color: PP.yellow,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>{I.pinFill({ width: 18, height: 18 })}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, fontFamily: PP.mono, fontWeight: 700 }}><CodeChip code={a.code}/></div>
              <div style={{ fontSize: 11.5, color: PP.text3, marginTop: 3 }}>{a.desc}</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 13, fontWeight: 800, color: PP.green }}>{a.amt}</div>
              <div style={{ fontSize: 10.5, color: PP.text3, marginTop: 3 }}>{a.when}</div>
            </div>
          </div>
        ))}
      </div>
      <TabBar active="activity"/>
    </Phone>
  );
}

// Profile screen
function ProfileScreen() {
  const items = [
    { l: 'Saved addresses', i: I.bookmark, r: '12' },
    { l: 'Offline maps', i: I.wifi_off, r: 'Download' },
    { l: 'Voice settings', i: I.mic, r: 'Hausa' },
    { l: 'Navigation settings', i: I.nav },
    { l: 'Account type', i: I.shield, r: 'Agent', accent: true },
    { l: 'Help & support', i: I.bell },
    { l: 'About PPOINNT', i: I.shield },
  ];
  return (
    <Phone>
      <div style={{ padding: '52px 20px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: -0.5 }}>Profile</div>
        <button style={{
          width: 38, height: 38, borderRadius: 12, border: `1px solid ${PP.line}`,
          background: PP.card, color: PP.text, display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{I.settings()}</button>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '0 20px 90px' }}>
        {/* User card */}
        <div style={{
          background: `linear-gradient(135deg, #1A1D24 0%, #14171C 100%)`,
          border: `1px solid ${PP.line}`, borderRadius: 20, padding: '16px',
          display: 'flex', alignItems: 'center', gap: 14, position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', right: -16, bottom: -16, opacity: 0.18 }}>
            <PinMarker size={80} glow={false}/>
          </div>
          <div style={{
            width: 64, height: 64, borderRadius: 18,
            background: 'linear-gradient(135deg, #3F2E1E 0%, #5C3F1F 100%)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: PP.yellow, fontWeight: 800, fontSize: 22, fontFamily: PP.font,
            border: '2px solid rgba(255,199,44,0.4)',
          }}>EO</div>
          <div style={{ position: 'relative', zIndex: 1 }}>
            <div style={{ fontSize: 17, fontWeight: 800, letterSpacing: -0.3 }}>Emmanuel O.</div>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 4, marginTop: 4,
              padding: '3px 8px', borderRadius: 6, background: 'rgba(255,199,44,0.14)',
              fontSize: 11, fontWeight: 700, color: PP.yellow,
            }}>{I.star({ width: 10, height: 10 })} Silver agent</div>
            <div style={{ fontSize: 12, color: PP.text3, marginTop: 6 }}>emmanuel@gmail.com</div>
          </div>
        </div>

        {/* List */}
        <div style={{
          marginTop: 14, background: PP.card, border: `1px solid ${PP.line}`,
          borderRadius: 18, overflow: 'hidden',
        }}>
          {items.map((it, i) => (
            <div key={i} style={{
              padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12,
              borderBottom: i < items.length - 1 ? `1px solid ${PP.line}` : 'none',
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 9,
                background: 'rgba(255,255,255,0.04)', color: PP.text2,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{it.i({ width: 16, height: 16 })}</div>
              <div style={{ flex: 1, fontSize: 14, fontWeight: 600 }}>{it.l}</div>
              {it.r && (
                <div style={{ fontSize: 12, fontWeight: 700, color: it.accent ? PP.yellow : PP.text3 }}>{it.r}</div>
              )}
              <div style={{ color: PP.text3 }}>{I.chevR()}</div>
            </div>
          ))}
        </div>

        {/* Theme toggle */}
        <div style={{
          marginTop: 14, padding: '14px 16px',
          background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 18,
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{
            width: 32, height: 32, borderRadius: 9, background: 'rgba(255,255,255,0.04)',
            color: PP.text2, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" stroke="currentColor" strokeWidth="1.8"/></svg>
          </div>
          <div style={{ flex: 1, fontSize: 14, fontWeight: 600 }}>Dark mode</div>
          {/* toggle */}
          <div style={{ width: 42, height: 24, borderRadius: 12, background: PP.yellow, padding: 2, display: 'flex', justifyContent: 'flex-end' }}>
            <div style={{ width: 20, height: 20, borderRadius: '50%', background: '#0A0B0D' }}/>
          </div>
        </div>
      </div>

      <TabBar active="profile"/>
    </Phone>
  );
}

// Low Network mode
function LowNetworkScreen() {
  return (
    <Phone>
      {/* offline indicator strip */}
      <div style={{ padding: '52px 0 0' }}>
        <div style={{
          padding: '10px 16px', background: 'rgba(245,158,11,0.1)', borderBottom: '1px solid rgba(245,158,11,0.18)',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <div style={{ color: PP.amber, display: 'flex' }}>{I.wifi_off()}</div>
          <div style={{ flex: 1, fontSize: 12.5, fontWeight: 600 }}>Low-data mode</div>
          <div style={{ fontSize: 11, color: PP.text3, fontWeight: 600 }}>Using cached maps</div>
        </div>
      </div>

      <div style={{ flex: 1, padding: '12px 20px 90px', display: 'flex', flexDirection: 'column', gap: 12, overflow: 'auto' }}>
        {/* Wireframe map */}
        <div style={{
          borderRadius: 20, overflow: 'hidden', position: 'relative',
          height: 200, background: '#0F1217', border: `1px solid ${PP.line}`,
        }}>
          <svg width="100%" height="100%" viewBox="0 0 340 200" preserveAspectRatio="xMidYMid slice" style={{ position: 'absolute', inset: 0 }}>
            <g stroke="rgba(255,255,255,0.08)" strokeWidth="1.2" fill="none">
              <path d="M0 60 L340 60"/>
              <path d="M0 100 L340 100"/>
              <path d="M0 140 L340 140"/>
              <path d="M80 0 L80 200"/>
              <path d="M180 0 L180 200"/>
              <path d="M260 0 L260 200"/>
            </g>
            {/* dashed route */}
            <path d="M40 170 L80 100 L180 100 L260 60" stroke={PP.yellow} strokeWidth="2.5" fill="none" strokeDasharray="6 6" strokeLinecap="round"/>
          </svg>
          <div style={{ position: 'absolute', left: 240, top: 40 }}><PinMarker size={28} glow={false}/></div>
          <div style={{ position: 'absolute', left: 30, top: 156 }}><UserDot size={14}/></div>
          <div style={{
            position: 'absolute', left: 12, top: 12,
            padding: '5px 10px', background: 'rgba(10,11,13,0.85)', borderRadius: 8,
            fontSize: 11, fontWeight: 600, color: PP.text2,
          }}>Wireframe view · 0.4MB</div>
        </div>

        {/* Sync card */}
        <div style={{
          background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 16,
          padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{
            width: 38, height: 38, borderRadius: 11, background: 'rgba(245,158,11,0.14)', color: PP.amber,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>{I.refresh()}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13.5, fontWeight: 700 }}>2 PPOINNTs waiting to sync</div>
            <div style={{ fontSize: 11.5, color: PP.text3, marginTop: 2 }}>Will upload when you're back online</div>
          </div>
          <div style={{ padding: '6px 10px', background: PP.yellow, color: '#0A0B0D', borderRadius: 8, fontSize: 11.5, fontWeight: 800 }}>Retry</div>
        </div>

        {/* Cached PPOINNTs */}
        <div>
          <div style={{ fontSize: 11.5, color: PP.text3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 8 }}>Saved offline</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {[
              { c: 'PPT-NG-LAG-IKD-1234', n: '15, Ajani Street' },
              { c: 'PPT-NG-LAG-YBA-5678', n: 'Office, Oregun' },
              { c: 'PPT-NG-ABJ-GRK-9012', n: 'Block 12, Garki' },
            ].map((p, i) => (
              <div key={i} style={{
                background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 12,
                padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 10,
              }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: PP.green }}/>
                <div style={{ flex: 1, fontSize: 12, fontFamily: PP.mono, fontWeight: 700 }}><CodeChip code={p.c}/></div>
                <div style={{ fontSize: 11, color: PP.text3 }}>{p.n}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Lightweight tip */}
        <div style={{
          marginTop: 6, padding: '12px 14px', borderRadius: 14,
          background: 'rgba(255,255,255,0.03)', border: `1px solid ${PP.line}`,
          fontSize: 12.5, color: PP.text2, lineHeight: 1.5,
        }}>
          <div style={{ fontWeight: 700, color: PP.text, marginBottom: 4 }}>Built for African networks</div>
          PPOINNT uses less than <b style={{ color: PP.yellow }}>30KB</b> per address. Works on 2G, EDGE, and intermittent connections.
        </div>
      </div>

      <TabBar active="map"/>
    </Phone>
  );
}

Object.assign(window, { AgentScreen, ActivityScreen, ProfileScreen, LowNetworkScreen });
