// PPOINNT — Driver navigation + Success ("Address Generated!") + Share

// Driver Navigation
function NavigateScreen() {
  return (
    <Phone>
      <div style={{ position: 'absolute', inset: 0 }}>
        <MapSurface mode="street" height="100%">
          {/* route line */}
          <svg width="100%" height="100%" viewBox="0 0 400 780" preserveAspectRatio="xMidYMid slice" style={{ position: 'absolute', inset: 0 }}>
            <defs>
              <linearGradient id="route" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#2E6BFF" stopOpacity="0.3"/>
                <stop offset="1" stopColor="#2E6BFF"/>
              </linearGradient>
            </defs>
            <path d="M200 700 L200 540 L130 460 L130 300 L260 220 L260 100" stroke="url(#route)" strokeWidth="10" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M200 700 L200 540 L130 460 L130 300 L260 220 L260 100" stroke="#fff" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="0 12 6" opacity="0.5"/>
          </svg>
          {/* destination pin */}
          <div style={{ position: 'absolute', left: '63%', top: '11%' }}><PinMarker size={36}/></div>
          {/* driver arrow */}
          <div style={{ position: 'absolute', left: '48%', top: '88%' }}>
            <div style={{ position: 'relative' }}>
              <div style={{
                position: 'absolute', inset: -16, borderRadius: '50%',
                background: 'radial-gradient(closest-side, rgba(46,107,255,0.4), transparent)',
              }}/>
              <svg width="34" height="34" viewBox="0 0 32 32">
                <path d="M16 2 L26 28 L16 22 L6 28 Z" fill={PP.blue} stroke="#fff" strokeWidth="2.5" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>
        </MapSurface>
      </div>

      {/* Top instruction card */}
      <div style={{ position: 'relative', zIndex: 5, padding: '52px 12px 0' }}>
        <div style={{
          background: 'rgba(20,22,28,0.92)', backdropFilter: 'blur(20px)',
          borderRadius: 20, padding: '14px 16px',
          display: 'flex', alignItems: 'center', gap: 14,
          border: `1px solid ${PP.line}`,
          boxShadow: '0 12px 32px rgba(0,0,0,0.35)',
        }}>
          <div style={{
            width: 56, height: 56, borderRadius: 16, background: PP.blue,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0,
          }}>
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
              <path d="M10 22 L10 14 L22 14 M22 14 L17 9 M22 14 L17 19" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
              <div style={{ fontSize: 30, fontWeight: 800, letterSpacing: -0.6, lineHeight: 1 }}>200</div>
              <div style={{ fontSize: 14, color: PP.text2, fontWeight: 600 }}>m</div>
            </div>
            <div style={{ fontSize: 15, fontWeight: 700, marginTop: 4 }}>Turn right onto Ajani St</div>
            <div style={{ fontSize: 12, color: PP.text3, marginTop: 2 }}>After the blue gate</div>
          </div>
        </div>

        {/* low data banner */}
        <div style={{
          marginTop: 10, padding: '8px 12px',
          background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.25)',
          borderRadius: 12, display: 'flex', alignItems: 'center', gap: 8,
          fontSize: 12, color: 'rgba(255,255,255,0.85)', fontWeight: 600,
          backdropFilter: 'blur(20px)',
        }}>
          <div style={{ color: PP.amber, display: 'flex' }}>{I.wifi_off()}</div>
          Low network · using offline maps
        </div>
      </div>

      {/* Right side controls */}
      <div style={{
        position: 'absolute', right: 12, top: 220, zIndex: 5,
        display: 'flex', flexDirection: 'column', gap: 8,
      }}>
        {[I.speaker, I.layers].map((Ic, i) => (
          <button key={i} style={{
            width: 44, height: 44, borderRadius: 14, border: `1px solid ${PP.line}`,
            background: 'rgba(20,22,28,0.92)', backdropFilter: 'blur(20px)',
            color: PP.text, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>{Ic()}</button>
        ))}
      </div>

      {/* Bottom card */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 10,
        background: PP.bg, borderTopLeftRadius: 28, borderTopRightRadius: 28,
        padding: '18px 20px 36px', borderTop: `1px solid ${PP.line}`,
      }}>
        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 16 }}>
          {[
            { v: '2.4', u: 'km', l: 'Distance' },
            { v: '12', u: 'min', l: 'ETA', highlight: true },
            { v: '10:45', u: 'AM', l: 'Arrival' },
          ].map((s, i) => (
            <div key={i} style={{ textAlign: i === 1 ? 'center' : (i === 0 ? 'left' : 'right') }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, justifyContent: i === 1 ? 'center' : (i === 0 ? 'flex-start' : 'flex-end') }}>
                <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: -0.4, color: s.highlight ? PP.yellow : PP.text }}>{s.v}</div>
                <div style={{ fontSize: 12, color: PP.text3, fontWeight: 600 }}>{s.u}</div>
              </div>
              <div style={{ fontSize: 11, color: PP.text3, marginTop: 2, fontWeight: 600 }}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* destination card */}
        <div style={{
          background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 16,
          padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12,
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 11, background: PP.yellowSoft, color: PP.yellow,
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          }}>{I.pinFill({ width: 18, height: 18 })}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12.5, fontWeight: 700 }}><CodeChip code="PPT-NG-LAG-IKD-1234"/></div>
            <div style={{ fontSize: 12, color: PP.text3, marginTop: 2 }}>15, Ajani St · Ikorodu, Lagos</div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10 }}>
          <button style={{
            flex: 1, height: 52, borderRadius: 16, border: 'none',
            background: PP.red, color: '#fff', fontFamily: PP.font, fontWeight: 700, fontSize: 15,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}>
            <svg width="14" height="14" viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/></svg>
            End trip
          </button>
          <button style={{
            width: 56, height: 52, borderRadius: 16, border: `1px solid ${PP.line}`,
            background: PP.card, color: PP.text, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>{I.mic()}</button>
        </div>
      </div>
    </Phone>
  );
}

// Success — Address Generated
function SuccessScreen() {
  return (
    <Phone>
      {/* confetti */}
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        <svg width="100%" height="100%" viewBox="0 0 380 780">
          {[
            [60, 220, PP.yellow], [320, 200, PP.blue], [80, 320, PP.green],
            [300, 340, PP.yellow], [120, 180, PP.blue], [280, 280, PP.yellow],
            [50, 380, PP.green], [330, 380, PP.yellow], [180, 140, PP.blue],
            [40, 260, PP.yellow], [340, 260, PP.green],
          ].map(([cx, cy, c], i) => (
            <g key={i} transform={`translate(${cx} ${cy}) rotate(${i * 31})`} opacity="0.85">
              <rect x="-3" y="-1" width="6" height="2" rx="1" fill={c}/>
            </g>
          ))}
        </svg>
      </div>

      <div style={{ padding: '52px 20px 0', flex: 1, display: 'flex', flexDirection: 'column' }}>
        {/* header */}
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <button style={{
            width: 38, height: 38, borderRadius: 12, border: 'none',
            background: PP.card, color: PP.text, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>{I.close({ width: 18, height: 18 })}</button>
        </div>

        {/* success */}
        <div style={{ textAlign: 'center', marginTop: 20 }}>
          <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: -0.4 }}>Address generated</div>
          <div style={{ fontSize: 13.5, color: PP.text3, marginTop: 6 }}>You can navigate, share, or save it now</div>
        </div>

        {/* check medallion */}
        <div style={{ display: 'flex', justifyContent: 'center', margin: '28px 0 22px' }}>
          <div style={{ position: 'relative', width: 110, height: 110 }}>
            <div style={{
              position: 'absolute', inset: -8, borderRadius: '50%',
              background: 'radial-gradient(closest-side, rgba(35,197,122,0.3), transparent)',
            }}/>
            <div style={{
              position: 'absolute', inset: 0, borderRadius: '50%',
              background: 'linear-gradient(180deg, #2EDA8A 0%, #1FB872 100%)',
              boxShadow: '0 16px 40px rgba(35,197,122,0.4), inset 0 0 0 6px rgba(255,255,255,0.06)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#fff',
            }}>
              <svg width="48" height="48" viewBox="0 0 24 24"><path d="M5 12.5l5 5 9-11" stroke="#fff" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" fill="none"/></svg>
            </div>
          </div>
        </div>

        {/* PPOINNT code card */}
        <div style={{
          background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 20,
          padding: '18px 20px', marginTop: 4,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ fontSize: 11, color: PP.text3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6 }}>Your PPOINNT</div>
            <div style={{
              width: 28, height: 28, borderRadius: 8, background: 'rgba(255,255,255,0.05)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', color: PP.text2,
            }}>{I.copy()}</div>
          </div>
          <div style={{ fontSize: 22, fontFamily: PP.mono, fontWeight: 800, marginTop: 10, letterSpacing: 0.5 }}>
            <CodeChip code="PPT-NG-LAG-IKD-1234"/>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 14, gap: 10 }}>
            <div style={{ flex: 1, padding: '10px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: 10 }}>
              <div style={{ fontSize: 11, color: PP.text3, fontWeight: 600 }}>Accuracy</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 3 }}>
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: PP.green }}/>
                <span style={{ fontSize: 13, fontWeight: 700, color: PP.green }}>High · ±3m</span>
              </div>
            </div>
            <div style={{ flex: 1, padding: '10px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: 10 }}>
              <div style={{ fontSize: 11, color: PP.text3, fontWeight: 600 }}>Type</div>
              <div style={{ fontSize: 13, fontWeight: 700, marginTop: 3 }}>House</div>
            </div>
          </div>
        </div>

        <div style={{ flex: 1 }}/>

        {/* actions */}
        <div style={{ marginBottom: 30, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <SecondaryBtn icon={I.share()}>Share PPOINNT</SecondaryBtn>
          <PrimaryBtn icon={I.nav()}>Navigate now</PrimaryBtn>
          <div style={{ textAlign: 'center', padding: '4px 0', fontSize: 14, color: PP.text3, fontWeight: 600 }}>Done</div>
        </div>
      </div>
    </Phone>
  );
}

// Share screen
function ShareScreen() {
  const shareIcons = [
    { id: 'wa', label: 'WhatsApp', icon: I.whatsapp, color: '#25D366' },
    { id: 'sms', label: 'SMS', icon: I.sms, color: PP.blue },
    { id: 'copy', label: 'Copy link', icon: I.link, color: PP.yellow },
    { id: 'more', label: 'More', icon: I.more, color: PP.text2 },
  ];
  return (
    <Phone>
      <ScreenHeader title="Share PPOINNT" left={I.back({ width: 18, height: 18 })} right={I.more({ width: 18, height: 18 })}/>

      <div style={{ padding: '4px 20px 0', flex: 1, overflow: 'auto' }}>
        {/* QR card */}
        <div style={{
          background: '#fff', borderRadius: 22, padding: '22px',
          display: 'flex', flexDirection: 'column', alignItems: 'center',
          color: '#0A0B0D',
        }}>
          {/* QR placeholder */}
          <div style={{
            width: 180, height: 180, borderRadius: 12, background: '#fff', position: 'relative',
            overflow: 'hidden',
          }}>
            <QRPattern/>
          </div>
          <div style={{ marginTop: 14, fontFamily: PP.mono, fontWeight: 800, fontSize: 15, letterSpacing: 0.4 }}>PPT-NG-LAG-IKD-1234</div>
          <div style={{ fontSize: 11.5, color: 'rgba(10,11,13,0.5)', marginTop: 4, fontWeight: 600 }}>Scan to open location</div>
        </div>

        {/* Share via */}
        <div style={{ marginTop: 24 }}>
          <div style={{ fontSize: 11.5, color: PP.text3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 12 }}>Share via</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
            {shareIcons.map(s => (
              <div key={s.id} style={{
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                padding: '14px 8px', background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 14,
              }}>
                <div style={{
                  width: 38, height: 38, borderRadius: 11,
                  background: s.id === 'wa' ? '#25D36622' : (s.id === 'sms' ? PP.blueSoft : (s.id === 'copy' ? PP.yellowSoft : 'rgba(255,255,255,0.05)')),
                  color: s.color, display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>{s.icon()}</div>
                <div style={{ fontSize: 10.5, fontWeight: 600, color: PP.text2 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Send to contact */}
        <div style={{ marginTop: 22 }}>
          <div style={{ fontSize: 11.5, color: PP.text3, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 10 }}>Send to contact</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { name: 'John Delivery', sub: '+234 802 123 4567', tag: 'rider', col: '#FF7A4D' },
              { name: 'Mary Johnson', sub: '+234 803 987 6543', tag: 'family', col: '#A66CFF' },
              { name: 'Customer support', sub: '+234 901 234 5678', tag: 'service', col: '#25D366' },
            ].map((c, i) => (
              <div key={i} style={{
                background: PP.card, border: `1px solid ${PP.line}`, borderRadius: 14,
                padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 12,
              }}>
                <div style={{
                  width: 38, height: 38, borderRadius: '50%',
                  background: c.col, color: '#fff',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontWeight: 700, fontSize: 13,
                }}>{c.name.split(' ').map(n => n[0]).join('')}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{c.name}</div>
                  <div style={{ fontSize: 12, color: PP.text3, marginTop: 2 }}>{c.sub}</div>
                </div>
                <div style={{
                  width: 32, height: 32, borderRadius: 10, background: 'rgba(37,211,102,0.14)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#25D366',
                }}>{I.whatsapp({ width: 16, height: 16 })}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ height: 30 }}/>
      </div>
    </Phone>
  );
}

// Procedurally drawn QR-ish pattern
function QRPattern() {
  // Deterministic pattern based on a small grid
  const size = 21;
  const cell = 180 / size;
  const cells = [];
  const seed = (i, j) => ((i * 13 + j * 7 + i * j) % 5) < 2;
  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      // skip finder regions
      const inFinder = (i < 7 && j < 7) || (i < 7 && j > size - 8) || (i > size - 8 && j < 7);
      if (inFinder) continue;
      if (seed(i, j)) cells.push([i, j]);
    }
  }
  const finder = (x, y) => (
    <g key={`f${x}${y}`}>
      <rect x={x} y={y} width={cell * 7} height={cell * 7} fill="#0A0B0D" rx={3}/>
      <rect x={x + cell} y={y + cell} width={cell * 5} height={cell * 5} fill="#fff" rx={2}/>
      <rect x={x + cell * 2} y={y + cell * 2} width={cell * 3} height={cell * 3} fill="#0A0B0D" rx={1}/>
    </g>
  );
  return (
    <svg width="180" height="180" viewBox="0 0 180 180">
      {cells.map(([i, j], idx) => (
        <rect key={idx} x={j * cell} y={i * cell} width={cell - 0.4} height={cell - 0.4} fill="#0A0B0D" rx={1}/>
      ))}
      {finder(0, 0)}
      {finder(180 - cell * 7, 0)}
      {finder(0, 180 - cell * 7)}
      {/* center logo overlay */}
      <rect x="74" y="74" width="32" height="32" rx="9" fill="#FFC72C"/>
      <g transform="translate(78 78)">
        <path d="M12 22s-7-7.5-7-13a7 7 0 1 1 14 0c0 5.5-7 13-7 13z" fill="#0A0B0D" transform="scale(1)"/>
        <circle cx="12" cy="9" r="2.5" fill="#FFC72C"/>
      </g>
    </svg>
  );
}

Object.assign(window, { NavigateScreen, SuccessScreen, ShareScreen });
